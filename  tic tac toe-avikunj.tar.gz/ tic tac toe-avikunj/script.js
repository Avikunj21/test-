$(document).ready(function(){
var count=0;
$(".innerRow1 div,.innerRow2 div,.innerRow3 div").click(function(){
  if(count%2==0)
  {
  $(this).append("<span style='font-size:80px;color:white;'>X</span>")
 
  count++
 }

 else{
	count++
$(this).append("<span style='font-size:80px;color:white;'>O</span>")
}
});
});

